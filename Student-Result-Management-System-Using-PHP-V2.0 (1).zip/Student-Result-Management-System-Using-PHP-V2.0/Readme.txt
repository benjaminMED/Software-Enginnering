Project Name: student Result Management System

How to run this Project

1. Download and Unzip file on your local system copy srms folder.

2. Put srms folder inside�root directory

Database Configuration

Open phpmyadmin
Create Database�srms
Import database srms.sql (available inside zip package)

For User

Open Your browser put inside browser http://localhost/srms

*********************Details of student**********************

Student name-- Anuj Kumar�
Roll id--10861
Student Class: Fourth(C)

********************For Admin Panel************************

Open Your browser put inside browser http://localhost/srms
Username :�admin
Password : Test@123


For More Details --- https://phpgurukul.com/student-result-management-system/